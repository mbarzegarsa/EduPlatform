// background.js - سرویس‌ورکر افزونه با پشتیبانی از پیام‌های پیشرفت

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        chrome.storage.local.set({
            defaultRows: 1000,
            theme: 'dark',
            firstRun: true
        });
        
        chrome.tabs.create({
            url: 'https://t.me/mbrzgrsa'
        });
    }
});

// مدیریت پیام‌ها از content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'progress' || request.type === 'complete' || request.type === 'error' || request.type === 'stopped') {
        chrome.runtime.sendMessage(request);
    } else if (request.action === 'showNotification') {
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'ابزارهای حرفه‌ای',
            message: request.message,
            priority: 2
        });
    }
    sendResponse({ received: true });
    return true;
});

chrome.storage.onChanged.addListener((changes, namespace) => {
    console.log('Settings changed:', changes);
});